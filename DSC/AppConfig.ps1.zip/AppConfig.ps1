﻿<#
    .AppConfig
    This configuration provisions File Server
#>

configuration AppConfig
{
    param(
        [Parameter(Mandatory)]
        [String]$DomainName
    )

    Import-DscResource -Module PSDesiredStateConfiguration, xSmbShare, xDisk, cDisk
    
    # Apply configuration
    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }     
    
        WindowsFeature 'FileServices' {
                Ensure = 'Present'
                Name = 'File-Services'
            }
            
    }

    xWaitforDisk Disk2
    {
        DiskNumber = 2
        RetryIntervalSec =$RetryIntervalSec
        RetryCount = $RetryCount
    }

    cDiskNoRestart ADDataDisk
    {
        DiskNumber = 2
        DriveLetter = 'S'
    }
}